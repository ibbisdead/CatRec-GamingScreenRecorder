package com.ibbie.catrec_gamingscreenrecorder

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import overlay.RecordingOverlay
import java.io.File
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.*
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import com.ibbie.catrec_gamingscreenrecorder.audio.MicRecorder

class ScreenRecorderService : Service() {

    companion object {
        private const val TAG = "ScreenRecorderService"
        private const val NOTIFICATION_ID = 1001
        const val CHANNEL_ID = "screen_recorder_channel"
        private const val CHANNEL_NAME = "Screen Recorder"
        const val ACTION_RECORDING_STOPPED = "com.ibbie.RECORDING_STOPPED"
    }

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var mediaCodec: MediaCodec? = null
    private var mediaMuxer: MediaMuxer? = null
    private var recordingOverlay: RecordingOverlay? = null

    private var screenWidth = 0
    private var screenHeight = 0
    private var screenDensity = 0
    private var bitrate = 0
    private var outputFile: File? = null
    private var isRecording = false
    private var isPaused = false
    private var videoTrackIndex = -1
    private var muxerStarted = false

    private var micRecorder: MicRecorder? = null
    private var micPcmFile: File? = null
    private var micAacFile: File? = null
    private var recordMic: Boolean = false

    private val stopRecordingReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == "com.ibbie.ACTION_STOP_RECORDING") {
                stopRecording()
            }
        }
    }

    private val controlReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                "com.ibbie.ACTION_STOP_RECORDING" -> stopRecording()
                "com.ibbie.ACTION_TOGGLE_PAUSE" -> togglePauseResume()
                "com.ibbie.ACTION_TOGGLE_MIC" -> toggleMicMute()
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        registerReceiver(stopRecordingReceiver, IntentFilter("com.ibbie.ACTION_STOP_RECORDING"))
        registerReceiver(controlReceiver, IntentFilter().apply {
            addAction("com.ibbie.ACTION_STOP_RECORDING")
            addAction("com.ibbie.ACTION_TOGGLE_PAUSE")
            addAction("com.ibbie.ACTION_TOGGLE_MIC")
        })
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            "START_RECORDING" -> {
                val resultCode = intent.getIntExtra("resultCode", Activity.RESULT_CANCELED)
                val data = intent.getParcelableExtra<Intent>("data")
                val width = intent.getIntExtra("width", 1920)
                val height = intent.getIntExtra("height", 1080)
                val density = intent.getIntExtra("density", 1)
                val bitrateValue = intent.getIntExtra("bitrate", 8000000)
                val orientation = intent.getIntExtra("orientation", 0)
                
                if (data != null) {
                    startRecording(resultCode, data, width, height, density, bitrateValue, orientation)
                }
            }
            "STOP_RECORDING" -> {
                stopRecording()
            }
        }
        return START_NOT_STICKY
    }

    private fun startRecording(
        resultCode: Int,
        data: Intent,
        width: Int,
        height: Int,
        density: Int,
        bitrateValue: Int,
        orientation: Int
    ) {
        if (isRecording) return

        screenWidth = width
        screenHeight = height
        screenDensity = density
        bitrate = bitrateValue

        // Create output file
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val fileName = "screen_recording_$timestamp.mp4"
        outputFile = File(getExternalFilesDir(null), fileName)

        // Mic PCM and AAC files
        micPcmFile = File(getExternalFilesDir(null), "mic_$timestamp.pcm")
        micAacFile = File(getExternalFilesDir(null), "mic_$timestamp.aac")

        // Set up MediaProjection
        val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = projectionManager.getMediaProjection(resultCode, data)

        // Set up MediaCodec
        val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, screenWidth, screenHeight)
        format.setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
        format.setInteger(MediaFormat.KEY_FRAME_RATE, 30)
        format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        format.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)

        mediaCodec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        mediaCodec?.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)

        // Set up MediaMuxer
        mediaMuxer = MediaMuxer(outputFile!!.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

        // Set up VirtualDisplay
        val surface = mediaCodec?.createInputSurface()
        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "ScreenRecording",
            screenWidth, screenHeight, screenDensity,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            surface, null, null
        )

        // Start recording
        mediaCodec?.start()
        isRecording = true
        muxerStarted = false

        // Start mic recording if requested
        recordMic = true // TODO: Set this based on intent or settings
        if (recordMic && micPcmFile != null) {
            micRecorder = MicRecorder(this, micPcmFile!!)
            micRecorder?.startRecording()
        }

        // Show notification
        startForeground(NOTIFICATION_ID, createNotification())

        // Show overlay
        recordingOverlay = RecordingOverlay(this)
        recordingOverlay?.show()

        // Start encoding thread
        Thread {
            encodeVideo()
        }.start()
    }

    private fun encodeVideo() {
        val bufferInfo = MediaCodec.BufferInfo()
        
        while (isRecording) {
            val outputBufferId = mediaCodec?.dequeueOutputBuffer(bufferInfo, 10000)
            
            when (outputBufferId) {
                MediaCodec.INFO_TRY_AGAIN_LATER -> {
                    // No output available yet
                }
                MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    // Format changed, add track to muxer
                    if (!muxerStarted) {
                        val format = mediaCodec?.outputFormat
                        if (format != null) {
                            videoTrackIndex = mediaMuxer?.addTrack(format) ?: -1
                            mediaMuxer?.start()
                            muxerStarted = true
                        }
                    }
                }
                MediaCodec.INFO_OUTPUT_BUFFERS_CHANGED -> {
                    // Ignore
                }
                else -> {
                    if (outputBufferId != null && outputBufferId >= 0) {
                        val outputBuffer = mediaCodec?.getOutputBuffer(outputBufferId)
                        if (outputBuffer != null && muxerStarted) {
                            mediaMuxer?.writeSampleData(videoTrackIndex, outputBuffer, bufferInfo)
                        }
                        mediaCodec?.releaseOutputBuffer(outputBufferId, false)
                    }
                }
            }
        }
    }

    private fun stopRecording() {
        if (!isRecording) return

        isRecording = false

        // Stop mic recording
        micRecorder?.stopRecording()
        micRecorder = null

        // Convert PCM to AAC if mic was recorded
        var micAacReady = false
        if (recordMic && micPcmFile != null && micPcmFile!!.exists()) {
            val pcmPath = micPcmFile!!.absolutePath
            val aacPath = micAacFile!!.absolutePath
            val ffmpegCmd = "-f s16le -ar 44100 -ac 1 -i $pcmPath -c:a aac -b:a 128k $aacPath"
            val session = FFmpegKit.execute(ffmpegCmd)
            micAacReady = ReturnCode.isSuccess(session.returnCode)
            if (micAacReady) {
                Log.d(TAG, "Mic PCM converted to AAC: $aacPath")
            } else {
                Log.e(TAG, "Failed to convert mic PCM to AAC")
            }
        }

        // Mux audio with video if needed
        val videoPath = outputFile?.absolutePath
        val micAacPath = micAacFile?.absolutePath
        val internalAacFile = File(outputFile?.parent, outputFile?.nameWithoutExtension + "_internal.aac")
        val internalAacPath = internalAacFile.absolutePath
        val finalOutputFile = File(outputFile?.parent, outputFile?.nameWithoutExtension + "_final.mp4")
        val hasInternalAac = internalAacFile.exists()
        val hasMicAac = micAacReady && micAacFile?.exists() == true
        if ((hasInternalAac || hasMicAac) && videoPath != null) {
            val muxCmd = when {
                hasInternalAac && hasMicAac ->
                    // Mix both audio tracks using amix
                    "-i \"$videoPath\" -i \"$internalAacPath\" -i \"$micAacPath\" -filter_complex [1:a][2:a]amix=inputs=2:duration=first[aout] -map 0:v -map \"[aout]\" -c:v copy -c:a aac -shortest \"${finalOutputFile.absolutePath}\""
                hasInternalAac ->
                    "-i \"$videoPath\" -i \"$internalAacPath\" -c:v copy -c:a aac -map 0:v -map 1:a -shortest \"${finalOutputFile.absolutePath}\""
                hasMicAac ->
                    "-i \"$videoPath\" -i \"$micAacPath\" -c:v copy -c:a aac -map 0:v -map 1:a -shortest \"${finalOutputFile.absolutePath}\""
                else -> null
            }
            if (muxCmd != null) {
                val session = FFmpegKit.execute(muxCmd)
                if (ReturnCode.isSuccess(session.returnCode)) {
                    Log.d(TAG, "Muxing succeeded: ${finalOutputFile.absolutePath}")
                } else {
                    Log.e(TAG, "Muxing failed: ${session.failStackTrace}")
                }
            }
        }

        // Stop video encoding
        mediaCodec?.stop()
        mediaCodec?.release()
        virtualDisplay?.release()
        mediaProjection?.stop()

        // Stop muxer
        if (muxerStarted) {
            mediaMuxer?.stop()
            mediaMuxer?.release()
        }

        // Hide overlay
        recordingOverlay?.hide()

        // Stop foreground service
        stopForeground(true)

        // Scan file for gallery
        outputFile?.let { file ->
            if (file.exists()) {
                // Use MediaScanner to make the file visible in gallery
                val intent = Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE)
                intent.data = android.net.Uri.fromFile(file)
                sendBroadcast(intent)
            }
        }

        // Send broadcast that recording stopped
        val broadcastIntent = Intent(ACTION_RECORDING_STOPPED).apply { setPackage(packageName) }
        sendBroadcast(broadcastIntent)

        // Stop service
        stopSelf()
    }

    private fun createNotification(): Notification {
        val stopIntent = Intent(this, StopRecordingReceiver::class.java)
        val stopPendingIntent = PendingIntent.getBroadcast(
            this, 0, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Screen Recording")
            .setContentText("Recording in progress...")
            .setSmallIcon(R.drawable.ic_recording)
            .setOngoing(true)
            .addAction(R.drawable.ic_stop, "Stop", stopPendingIntent)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_LOW
            )
            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun togglePauseResume() {
        isPaused = !isPaused
        // Add actual pause/resume logic for video/audio here if needed
        Log.d(TAG, if (isPaused) "Recording paused" else "Recording resumed")
    }

    private fun toggleMicMute() {
        // Add actual mic mute/unmute logic here if needed
        Log.d(TAG, "Mic mute toggled")
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(stopRecordingReceiver)
        unregisterReceiver(controlReceiver)
        stopRecording()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
