package com.ibbie.catrec_gamingscreenrecorder

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.settingsDataStore by preferencesDataStore(name = "settings")

object SettingsKeys {
    val VIDEO_BITRATE = intPreferencesKey("video_bitrate")
    val RESOLUTION = stringPreferencesKey("resolution")
    val AUDIO_BITRATE = stringPreferencesKey("audio_bitrate")
    val AUDIO_SAMPLE_RATE = stringPreferencesKey("audio_sample_rate")
    val AUDIO_CHANNEL = stringPreferencesKey("audio_channel")
    val FPS = intPreferencesKey("fps")
    val MIC_VOLUME = intPreferencesKey("mic_volume")
    val NOISE_SUPPRESSION = booleanPreferencesKey("noise_suppression")
    val RECORDING_OVERLAY = booleanPreferencesKey("recording_overlay")
    val PAUSE_ON_SCREEN_OFF = booleanPreferencesKey("pause_on_screen_off")
    val OVERLAY_ENABLED = booleanPreferencesKey("overlay_enabled")
    val OVERLAY_BUTTON = booleanPreferencesKey("overlay_button")

    val AUDIO_SOURCE = stringPreferencesKey("audio_source")
    val ORIENTATION = stringPreferencesKey("orientation")
    val FILE_DESTINATION = stringPreferencesKey("file_destination")
    val SHOW_TOUCHES = booleanPreferencesKey("show_touches")
    val COUNTDOWN = intPreferencesKey("countdown")
    val STOP_OPTIONS = stringSetPreferencesKey("stop_options")
    val THEME_DARK = booleanPreferencesKey("theme_dark")
}

class SettingsDataStore(private val context: Context) {
    val videoBitrate: Flow<Int> = context.settingsDataStore.data.map { it[SettingsKeys.VIDEO_BITRATE] ?: 8000000 }
    val resolution: Flow<String> = context.settingsDataStore.data.map { it[SettingsKeys.RESOLUTION] ?: "Native" }
    val audioBitrate: Flow<String> = context.settingsDataStore.data.map { it[SettingsKeys.AUDIO_BITRATE] ?: "128 kbps" }
    val audioSampleRate: Flow<String> = context.settingsDataStore.data.map { it[SettingsKeys.AUDIO_SAMPLE_RATE] ?: "44100 Hz" }
    val audioChannel: Flow<String> = context.settingsDataStore.data.map { it[SettingsKeys.AUDIO_CHANNEL] ?: "Stereo" }
    val fps: Flow<Int> = context.settingsDataStore.data.map { it[SettingsKeys.FPS] ?: 60 }
    val micVolume: Flow<Int> = context.settingsDataStore.data.map { it[SettingsKeys.MIC_VOLUME] ?: 100 }
    val noiseSuppression: Flow<Boolean> = context.settingsDataStore.data.map { it[SettingsKeys.NOISE_SUPPRESSION] ?: false }
    val recordingOverlay: Flow<Boolean> = context.settingsDataStore.data.map { it[SettingsKeys.RECORDING_OVERLAY] ?: true }
    val pauseOnScreenOff: Flow<Boolean> = context.settingsDataStore.data.map { it[SettingsKeys.PAUSE_ON_SCREEN_OFF] ?: false }
    val overlayEnabled: Flow<Boolean> = context.settingsDataStore.data.map { it[SettingsKeys.OVERLAY_ENABLED] ?: false }
    val overlayButton: Flow<Boolean> = context.settingsDataStore.data.map { it[SettingsKeys.OVERLAY_BUTTON] ?: true }

    val audioSource: Flow<String> = context.settingsDataStore.data.map { it[SettingsKeys.AUDIO_SOURCE] ?: "System Audio" }
    val orientation: Flow<String> = context.settingsDataStore.data.map { it[SettingsKeys.ORIENTATION] ?: "Auto" }
    val fileDestination: Flow<String> = context.settingsDataStore.data.map { it[SettingsKeys.FILE_DESTINATION] ?: "/storage/emulated/0/Movies/CatRec" }
    val showTouches: Flow<Boolean> = context.settingsDataStore.data.map { it[SettingsKeys.SHOW_TOUCHES] ?: false }
    val countdown: Flow<Int> = context.settingsDataStore.data.map { it[SettingsKeys.COUNTDOWN] ?: 0 }
    val stopOptions: Flow<Set<String>> = context.settingsDataStore.data.map { it[SettingsKeys.STOP_OPTIONS] ?: setOf("Screen Off") }
    val themeDark: Flow<Boolean> = context.settingsDataStore.data.map { it[SettingsKeys.THEME_DARK] ?: true }

    suspend fun setVideoBitrate(value: Int) = context.settingsDataStore.edit { it[SettingsKeys.VIDEO_BITRATE] = value }
    suspend fun setResolution(value: String) = context.settingsDataStore.edit { it[SettingsKeys.RESOLUTION] = value }
    suspend fun setAudioBitrate(value: String) = context.settingsDataStore.edit { it[SettingsKeys.AUDIO_BITRATE] = value }
    suspend fun setAudioSampleRate(value: String) = context.settingsDataStore.edit { it[SettingsKeys.AUDIO_SAMPLE_RATE] = value }
    suspend fun setAudioChannel(value: String) = context.settingsDataStore.edit { it[SettingsKeys.AUDIO_CHANNEL] = value }
    suspend fun setFps(value: Int) = context.settingsDataStore.edit { it[SettingsKeys.FPS] = value }
    suspend fun setMicVolume(value: Int) = context.settingsDataStore.edit { it[SettingsKeys.MIC_VOLUME] = value }
    suspend fun setNoiseSuppression(value: Boolean) = context.settingsDataStore.edit { it[SettingsKeys.NOISE_SUPPRESSION] = value }
    suspend fun setRecordingOverlay(value: Boolean) = context.settingsDataStore.edit { it[SettingsKeys.RECORDING_OVERLAY] = value }
    suspend fun setPauseOnScreenOff(value: Boolean) = context.settingsDataStore.edit { it[SettingsKeys.PAUSE_ON_SCREEN_OFF] = value }
    suspend fun setOverlayEnabled(value: Boolean) = context.settingsDataStore.edit { it[SettingsKeys.OVERLAY_ENABLED] = value }
    suspend fun setOverlayButton(value: Boolean) = context.settingsDataStore.edit { it[SettingsKeys.OVERLAY_BUTTON] = value }

    suspend fun setAudioSource(value: String) = context.settingsDataStore.edit { it[SettingsKeys.AUDIO_SOURCE] = value }
    suspend fun setOrientation(value: String) = context.settingsDataStore.edit { it[SettingsKeys.ORIENTATION] = value }
    suspend fun setFileDestination(value: String) = context.settingsDataStore.edit { it[SettingsKeys.FILE_DESTINATION] = value }
    suspend fun setShowTouches(value: Boolean) = context.settingsDataStore.edit { it[SettingsKeys.SHOW_TOUCHES] = value }
    suspend fun setCountdown(value: Int) = context.settingsDataStore.edit { it[SettingsKeys.COUNTDOWN] = value }
    suspend fun setStopOptions(value: Set<String>) = context.settingsDataStore.edit { it[SettingsKeys.STOP_OPTIONS] = value }
    suspend fun setThemeDark(value: Boolean) = context.settingsDataStore.edit { it[SettingsKeys.THEME_DARK] = value }
} 