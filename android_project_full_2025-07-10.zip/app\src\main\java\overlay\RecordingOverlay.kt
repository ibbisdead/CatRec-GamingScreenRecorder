package overlay

import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.view.*
import android.widget.ImageView
import android.widget.LinearLayout
import com.ibbie.catrec_gamingscreenrecorder.R
import com.ibbie.catrec_gamingscreenrecorder.ScreenRecorderService
import kotlin.math.absoluteValue

class RecordingOverlay(private val context: Context) {

    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private var isShowing = false

    fun show() {
        if (isShowing) return

        val inflater = LayoutInflater.from(context)
        overlayView = inflater.inflate(R.layout.overlay_bubble, null)

        val layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )

        layoutParams.gravity = Gravity.TOP or Gravity.START
        layoutParams.x = 100
        layoutParams.y = 300

        windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        windowManager?.addView(overlayView, layoutParams)
        isShowing = true

        // Handle drag and actions
        val bubble = overlayView!!.findViewById<ImageView>(R.id.overlay_bubble)
        bubble.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f

            override fun onTouch(v: View?, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = layoutParams.x
                        initialY = layoutParams.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        return true
                    }

                    MotionEvent.ACTION_MOVE -> {
                        layoutParams.x = initialX + (event.rawX - initialTouchX).toInt()
                        layoutParams.y = initialY + (event.rawY - initialTouchY).toInt()
                        windowManager?.updateViewLayout(overlayView, layoutParams)
                        return true
                    }

                    MotionEvent.ACTION_UP -> {
                        // Short tap -> show controls
                        val deltaX = (event.rawX - initialTouchX).toInt()
                        val deltaY = (event.rawY - initialTouchY).toInt()
                        if (deltaX.absoluteValue < 10 && deltaY.absoluteValue < 10) {
                            toggleControlPanel()
                        }
                        return true
                    }
                }
                return false
            }
        })

        setupControls()
    }

    private fun setupControls() {
        val stopButton = overlayView?.findViewById<View>(R.id.btn_stop)
        val pauseButton = overlayView?.findViewById<View>(R.id.btn_pause)
        val muteButton = overlayView?.findViewById<View>(R.id.btn_mic)

        stopButton?.setOnClickListener {
            val intent = Intent("com.ibbie.ACTION_STOP_RECORDING")
            intent.setPackage(context.packageName)
            context.sendBroadcast(intent)
            hide()
        }

        pauseButton?.setOnClickListener {
            val intent = Intent("com.ibbie.ACTION_TOGGLE_PAUSE")
            intent.setPackage(context.packageName)
            context.sendBroadcast(intent)
        }

        muteButton?.setOnClickListener {
            val intent = Intent("com.ibbie.ACTION_TOGGLE_MIC")
            intent.setPackage(context.packageName)
            context.sendBroadcast(intent)
        }
    }

    private fun toggleControlPanel() {
        val panel = overlayView?.findViewById<LinearLayout>(R.id.overlay_controls)
        panel?.visibility =
            if (panel?.visibility == View.VISIBLE) View.GONE else View.VISIBLE
    }

    fun hide() {
        if (!isShowing) return
        windowManager?.removeView(overlayView)
        overlayView = null
        isShowing = false
    }
}
